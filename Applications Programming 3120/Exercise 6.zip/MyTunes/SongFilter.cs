﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTunes
{
    public class SongFilter
    {
        public String SongName { get; set; }
        public String MinYear { get; set; }
        public String MaxYear { get; set; }
        public String MinRating { get; set; }
        public String MaxRating { get; set; }
    }
}
