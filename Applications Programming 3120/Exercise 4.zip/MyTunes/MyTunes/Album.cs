﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTunes
{
    public class Album : Song
    {
        public int AlbumName
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
