﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTunes
{
    public class Artist : Song
    {
        public int ArtistName
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
