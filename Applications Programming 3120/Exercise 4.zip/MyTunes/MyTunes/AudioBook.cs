﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTunes
{
    public class AudioBook : PlayableItem
    {
        public int AudioBookName
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int AuthorName
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int NarratorName
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int YearReleased
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
