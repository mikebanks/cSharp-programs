﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTunes
{
    public class Author : AudioBook
    {
        public int AuthorName
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
